
import React from 'react';

interface InputFieldProps {
  label: string;
  value: string;
  onChange: (val: string) => void;
  placeholder?: string;
  description?: string;
  type?: 'text' | 'date' | 'textarea';
  icon?: string; // Nueva prop para el icono
}

const InputField: React.FC<InputFieldProps> = ({ label, value, onChange, placeholder, description, type = 'text', icon }) => {
  // Ajuste de clases base para tipografía más limpia y padding condicional si hay icono
  const baseClasses = `w-full bg-[#f8fbff] border border-[#d1e6f9] py-3.5 focus:bg-white focus:border-[#0078d4] focus:ring-4 focus:ring-[#0078d4]/10 focus:outline-none transition-all duration-200 text-[#323130] placeholder-[#a19f9d] shadow-sm rounded-xl font-medium text-[15px] ${icon ? 'pl-11 pr-5' : 'px-5'}`;

  return (
    <div className="mb-6 last:mb-0">
      {label && (
        <label className="block text-[15px] font-medium text-[#323130] mb-2 ml-1">
          {label}
        </label>
      )}
      {description && <p className="text-[11px] text-[#605e5c] mb-3 ml-1 leading-tight italic">{description}</p>}
      
      <div className="relative">
        {icon && (
          <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-[#a19f9d] pointer-events-none z-10">
            <i className={`${icon} text-lg opacity-70`}></i>
          </div>
        )}

        {type === 'textarea' ? (
          <textarea
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder={placeholder || 'Escriba su respuesta...'}
            className={`${baseClasses} min-h-[100px] resize-none`}
          />
        ) : (
          <input
            type={type}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder={placeholder || 'Tu respuesta'}
            className={baseClasses}
          />
        )}
      </div>
    </div>
  );
};

export default InputField;
