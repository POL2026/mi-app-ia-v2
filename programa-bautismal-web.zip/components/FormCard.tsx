
import React from 'react';

interface FormCardProps {
  children: React.ReactNode;
  active?: boolean;
  isHeader?: boolean;
}

const FormCard: React.FC<FormCardProps> = ({ children, isHeader }) => {
  return (
    <div className={`bg-white rounded-md ms-shadow mb-6 overflow-hidden ${isHeader ? 'border-t-[6px] border-[#0078d4]' : ''}`}>
      <div className="p-8">
        {children}
      </div>
    </div>
  );
};

export default FormCard;
