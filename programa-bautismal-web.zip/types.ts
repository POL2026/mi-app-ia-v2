
export interface BaptismalFormData {
  nombres: string[]; // Array para múltiples nombres
  fecha: string;
  fotoPerfil: string; // Base64 o URL de la imagen
  preludioPianista: boolean;
  preludioGrabacion: boolean;
  himnoApertura: string;
  dirigeHimno: string;
  pianistaApertura: string;
  oracionApertura: string;
  mensaje1: string;
  tema1: string;
  mensaje2: string;
  tema2: string;
  numeroMusical: string;
  oficiantes: string[]; // CAMBIO: Array para múltiples oficiantes
  testigo1: string;
  testigo2: string;
  reverenciaHimnos: boolean;
  reverenciaPrimaria: boolean;
  portavocesConfirmacion: string[]; // CAMBIO: Array para múltiples portavoces
  acompanantesConfirmacion: string[]; // CAMBIO: Array para múltiples acompañantes
  himnoFinal: string;
  oracionFinal: string;
  posludioPianista: boolean;
  posludioGrabacion: boolean;
}

export const initialFormData: BaptismalFormData = {
  nombres: [''], 
  fecha: '',
  fotoPerfil: '',
  preludioPianista: false,
  preludioGrabacion: false,
  himnoApertura: '',
  dirigeHimno: '',
  pianistaApertura: '',
  oracionApertura: '',
  mensaje1: '',
  tema1: '',
  mensaje2: '',
  tema2: '',
  numeroMusical: '',
  oficiantes: [''], // Inicializado como array
  testigo1: '',
  testigo2: '',
  reverenciaHimnos: false,
  reverenciaPrimaria: false,
  portavocesConfirmacion: [''], // Inicializado como array
  acompanantesConfirmacion: [''], // Inicializado como array
  himnoFinal: '',
  oracionFinal: '',
  posludioPianista: false,
  posludioGrabacion: false,
};
