
import React, { useState, useRef } from 'react';
import { BaptismalFormData, initialFormData } from './types';
import FormCard from './components/FormCard';
import InputField from './components/InputField';

// --- COMPONENTES AUXILIARES (Definidos fuera de App para evitar pérdida de foco) ---

const SectionTitle = ({ number, title }: { number: string, title: string }) => (
  <div className="flex items-center gap-4 mb-6 mt-2">
    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-[#0078d4] text-white text-sm font-bold shrink-0 shadow-md">
      {number}
    </div>
    <h2 className="text-[20px] font-semibold text-[#2b3a67] tracking-tight">{title}</h2>
  </div>
);

const Separator = () => <div className="h-[1px] bg-gradient-to-r from-transparent via-[#d1e6f9] to-transparent my-10" />;

const CheckboxItem = ({ label, checked, onChange }: { label: string, checked: boolean, onChange: (val: boolean) => void }) => (
  <label className={`flex items-center group cursor-pointer p-3 px-5 rounded-xl border transition-all duration-200 flex-1 shadow-sm ${checked ? 'bg-[#f0f7ff] border-[#0078d4] ring-1 ring-[#0078d4]/20' : 'bg-white border-[#d1e6f9] hover:border-[#0078d4] hover:bg-[#fafcfe]'}`}>
    <div className="relative flex items-center justify-center">
      <input 
        type="checkbox" 
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        className="sr-only"
      />
      <div className={`w-5 h-5 rounded border-2 transition-all flex items-center justify-center ${checked ? 'bg-[#0078d4] border-[#0078d4]' : 'bg-white border-[#c8c6c4] group-hover:border-[#0078d4]'}`}>
        {checked && <i className="fas fa-check text-[10px] text-white"></i>}
      </div>
    </div>
    <span className={`ml-3 text-[14px] font-medium transition-colors ${checked ? 'text-[#004e8c]' : 'text-[#605e5c]'}`}>
      {label}
    </span>
  </label>
);

const DynamicFieldGroup = ({ 
  items, 
  fieldKey, 
  placeholder, 
  label,
  description,
  onUpdate,
  onDuplicate,
  onRemove
}: { 
  items: string[], 
  fieldKey: keyof BaptismalFormData, 
  placeholder: string,
  label?: string,
  description?: string,
  onUpdate: (key: keyof BaptismalFormData, index: number, value: string) => void,
  onDuplicate: (key: keyof BaptismalFormData, index: number) => void,
  onRemove: (key: keyof BaptismalFormData, index: number) => void
}) => (
  <div className="flex flex-col w-full">
    {label && <label className="block text-[15px] font-medium text-[#323130] mb-2 ml-1">{label}</label>}
    {description && <p className="text-[11px] text-[#605e5c] mb-3 ml-1 leading-tight italic">{description}</p>}
    
    {items.map((item, index) => (
      <div key={index} className="w-full mb-5 group relative">
        <div className="w-full relative">
          <InputField 
            label=""
            placeholder={placeholder}
            value={item} 
            onChange={(v) => onUpdate(fieldKey, index, v)}
            icon="fas fa-user" 
          />
        </div>
        
        <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-2 opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 transition-opacity duration-200 z-20">
          <button 
            onClick={() => onDuplicate(fieldKey, index)}
            title="Duplicar"
            className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-50 border border-gray-100 text-[#a19f9d] hover:bg-white hover:text-[#0078d4] hover:shadow-md transition-all focus:outline-none transform hover:scale-105"
          >
            <i className="far fa-copy text-xs"></i>
          </button>
          
          {items.length > 1 && (
            <button 
              onClick={() => onRemove(fieldKey, index)}
              title="Eliminar"
              className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-50 border border-gray-100 text-[#a19f9d] hover:bg-white hover:text-red-500 hover:shadow-md transition-all focus:outline-none transform hover:scale-105"
            >
              <i className="far fa-trash-alt text-xs"></i>
            </button>
          )}
        </div>
      </div>
    ))}
  </div>
);

// --- COMPONENTE PRINCIPAL ---

const App: React.FC = () => {
  const [formData, setFormData] = useState<BaptismalFormData>(initialFormData);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const updateField = <K extends keyof BaptismalFormData>(key: K, value: BaptismalFormData[K]) => {
    setFormData(prev => ({ ...prev, [key]: value }));
  };

  // --- LÓGICA GENÉRICA PARA CAMPOS DUPLICABLES (Arrays) ---
  const updateArray = (key: keyof BaptismalFormData, index: number, value: string) => {
    if (Array.isArray(formData[key])) {
      const newArray = [...(formData[key] as string[])];
      newArray[index] = value;
      setFormData(prev => ({ ...prev, [key]: newArray }));
    }
  };

  const duplicateArrayItem = (key: keyof BaptismalFormData, index: number) => {
    if (Array.isArray(formData[key])) {
      const newArray = [...(formData[key] as string[])];
      newArray.splice(index + 1, 0, newArray[index]);
      setFormData(prev => ({ ...prev, [key]: newArray }));
    }
  };

  const removeArrayItem = (key: keyof BaptismalFormData, index: number) => {
    const currentArray = formData[key] as string[];
    if (currentArray.length > 1) {
      const newArray = currentArray.filter((_, i) => i !== index);
      setFormData(prev => ({ ...prev, [key]: newArray }));
    }
  };
  // --------------------------------------------------------

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        updateField('fotoPerfil', reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const formatDate = (dateStr: string) => {
    if (!dateStr) return '';
    try {
      const date = new Date(dateStr + 'T12:00:00');
      return new Intl.DateTimeFormat('es-ES', { 
        day: 'numeric', 
        month: 'long', 
        year: 'numeric' 
      }).format(date);
    } catch (e) {
      return dateStr;
    }
  };

  return (
    <div className="min-h-screen pb-20 bg-[#f3f2f1]">
      {/* Banner Superior - Color sólido #0078d4 sin vectores */}
      <div className="h-64 bg-[#0078d4] w-full relative flex items-center justify-around text-white no-print overflow-hidden shadow-md px-10">
         {/* Vectores eliminados */}
      </div>

      <div className="max-w-[800px] mx-auto -mt-24 px-4 relative z-10">
        
        {/* BLOQUE ENCABEZADO */}
        <div className="bg-white rounded-md ms-shadow mb-6 overflow-hidden border-t-[10px] border-[#4a90e2]">
          <div className="p-8">
            <div className="flex flex-col items-center text-center pt-2">
              <div className="relative mb-6 mt-4">
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={handleImageUpload} 
                  className="hidden" 
                  accept="image/*"
                />
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="group w-40 h-40 sm:w-48 sm:h-48 rounded-2xl border-[4px] border-white bg-white flex items-center justify-center overflow-hidden cursor-pointer hover:shadow-2xl hover:border-[#4a90e2]/20 transition-all duration-300 shadow-md relative"
                >
                  {formData.fotoPerfil ? (
                    <img src={formData.fotoPerfil} alt="Perfil" className="w-full h-full object-contain" />
                  ) : (
                    <div className="text-center flex flex-col items-center justify-center p-4 transition-transform duration-300 group-hover:scale-105">
                      <div className="w-16 h-16 rounded-full bg-[#f0f7ff] flex items-center justify-center mb-3 group-hover:bg-[#4a90e2] transition-colors duration-300">
                        <i className="fas fa-camera text-3xl text-[#4a90e2] group-hover:text-white transition-colors duration-300"></i>
                      </div>
                      <p className="text-[10px] font-black uppercase tracking-widest text-[#4a90e2] mb-1">Cargar Foto</p>
                    </div>
                  )}
                </div>
                {formData.fotoPerfil && (
                  <button 
                    onClick={(e) => { e.stopPropagation(); updateField('fotoPerfil', ''); }}
                    className="absolute -top-2 -right-2 bg-red-500 text-white shadow-lg rounded-full w-8 h-8 flex items-center justify-center hover:bg-red-600 transition-colors no-print border-2 border-white z-20"
                  >
                    <i className="fas fa-times text-xs"></i>
                  </button>
                )}
              </div>

              <h1 className="text-[32px] font-semibold text-[#2b3a67] leading-none mb-4 uppercase tracking-tight">PROGRAMA BAUTISMAL</h1>
              
              <div className="w-full grid grid-cols-1 md:grid-cols-2 gap-x-8 text-left border-t border-[#e2e8f0] pt-10 items-start mt-6">
                
                {/* Sección de Nombres Dinámicos */}
                <DynamicFieldGroup 
                  items={formData.nombres}
                  fieldKey="nombres"
                  placeholder="Nombre completo"
                  onUpdate={updateArray}
                  onDuplicate={duplicateArrayItem}
                  onRemove={removeArrayItem}
                />

                {/* Sección de Fecha */}
                <div className="mb-6">
                  <div className="relative group w-full">
                    <input 
                      type="date"
                      value={formData.fecha}
                      onChange={(e) => updateField('fecha', e.target.value)}
                      className="absolute inset-0 w-full h-full opacity-0 z-20 cursor-pointer"
                    />
                    
                    <div className={`w-full bg-[#f8fbff] border border-[#d1e6f9] py-3.5 px-5 rounded-xl flex items-center gap-4 transition-all duration-200 shadow-sm min-h-[52px] ${formData.fecha ? 'text-[#323130]' : 'text-[#a19f9d]'} group-hover:border-[#0078d4] group-hover:bg-white`}>
                      <i className={`fas fa-calendar-alt text-lg opacity-70 flex-shrink-0 ${formData.fecha ? 'text-[#0078d4]' : 'text-[#a19f9d]'}`}></i>
                      
                      <div className="flex flex-col justify-center flex-grow font-medium text-[15px]">
                         {formData.fecha ? (
                           <span className="text-[#323130] lowercase">
                             {formatDate(formData.fecha)}
                           </span>
                         ) : (
                           <span className="text-[#a19f9d]">Seleccionar fecha</span>
                         )}
                      </div>
                      
                      <i className="fas fa-chevron-down text-xs text-[#a19f9d] opacity-50"></i>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
        </div>

        {/* BLOQUE 1 */}
        <FormCard>
          <SectionTitle number="1" title="Música de preludio" />
          <div className="bg-[#f8f9fa] p-5 rounded-2xl border border-[#edebe9] mb-8">
            <p className="text-[11px] text-[#605e5c] mb-4 ml-1 italic font-medium leading-relaxed">
              La música reverente antes del comienzo puede propiciar el espíritu de adoración
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              <CheckboxItem 
                label="Pianista u organista" 
                checked={formData.preludioPianista} 
                onChange={(v) => updateField('preludioPianista', v)} 
              />
              <CheckboxItem 
                label="Grabación" 
                checked={formData.preludioGrabacion} 
                onChange={(v) => updateField('preludioGrabacion', v)} 
              />
            </div>
          </div>
          
          <Separator />

          <SectionTitle number="2" title="Breve bienvenida" />
          <div className="mb-8" />

          <Separator />

          <SectionTitle number="3" title="Himno y oración de apertura" />
          <div className="grid grid-cols-1 gap-2">
            <InputField label="Himno" value={formData.himnoApertura} onChange={(v) => updateField('himnoApertura', v)} />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4">
              <InputField label="Dirige himno" value={formData.dirigeHimno} onChange={(v) => updateField('dirigeHimno', v)} />
              <InputField label="Pianista" value={formData.pianistaApertura} onChange={(v) => updateField('pianistaApertura', v)} />
            </div>
            <InputField label="Oración" value={formData.oracionApertura} onChange={(v) => updateField('oracionApertura', v)} />
          </div>
        </FormCard>

        {/* BLOQUE 2: 4, 5, 6 y 7 */}
        <FormCard>
          <SectionTitle number="4" title="Mensajes breves" />
          <p className="text-[12px] text-[#605e5c] mb-6 ml-1">
            Uno o dos mensajes breves sobre temas del Evangelio, tales como el bautismo y el don del Espíritu Santo.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6">
            <InputField label="1° Mensaje" value={formData.mensaje1} onChange={(v) => updateField('mensaje1', v)} />
            <InputField label="Tema" value={formData.tema1} onChange={(v) => updateField('tema1', v)} />
            <InputField label="2° Mensaje" value={formData.mensaje2} onChange={(v) => updateField('mensaje2', v)} />
            <InputField label="Tema" value={formData.tema2} onChange={(v) => updateField('tema2', v)} />
          </div>

          <Separator />

          <SectionTitle number="5" title="Un número musical" />
          <InputField 
            label="" 
            description="La música debe presentarse con espíritu de adoración al Padre Celestial y a Jesucristo, no como una presentación para exhibir el talento musical."
            value={formData.numeroMusical} 
            onChange={(v) => updateField('numeroMusical', v)} 
          />

          <Separator />

          <SectionTitle number="6" title="El bautismo y testigos" />
          <div className="space-y-4">
            {/* OFICIANTE - CAMPO DINÁMICO */}
            <DynamicFieldGroup 
              items={formData.oficiantes}
              fieldKey="oficiantes"
              placeholder="Nombre del Oficiante"
              label="Oficiante(s)"
              description="Debe ser aprobado por el obispo (o presidente de misión si es misionero)."
              onUpdate={updateArray}
              onDuplicate={duplicateArrayItem}
              onRemove={removeArrayItem}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <InputField label="Testigo 1" value={formData.testigo1} onChange={(v) => updateField('testigo1', v)} />
              <InputField label="Testigo 2" value={formData.testigo2} onChange={(v) => updateField('testigo2', v)} />
            </div>
          </div>

          <Separator />

          <SectionTitle number="7" title="Tiempo de reverencia" />
          <div className="flex flex-col sm:flex-row gap-4">
            <CheckboxItem 
              label="Tocar o cantar himnos" 
              checked={formData.reverenciaHimnos} 
              onChange={(v) => updateField('reverenciaHimnos', v)} 
            />
            <CheckboxItem 
              label="Cantar canciones de la primaria" 
              checked={formData.reverenciaPrimaria} 
              onChange={(v) => updateField('reverenciaPrimaria', v)} 
            />
          </div>
        </FormCard>

        {/* BLOQUE 3: 8, 9, 10 y 11 */}
        <FormCard>
          <SectionTitle number="8" title="La confirmación" />
          <div className="space-y-4">
            {/* PORTAVOZ - CAMPO DINÁMICO */}
            <DynamicFieldGroup 
              items={formData.portavocesConfirmacion}
              fieldKey="portavocesConfirmacion"
              placeholder="Nombre del Portavoz"
              label="Portavoz"
              description="Debe ser aprobado por el obispo (o presidente de misión si es misionero)."
              onUpdate={updateArray}
              onDuplicate={duplicateArrayItem}
              onRemove={removeArrayItem}
            />

            {/* ACOMPAÑANTES - CAMPO DINÁMICO */}
            <DynamicFieldGroup 
              items={formData.acompanantesConfirmacion}
              fieldKey="acompanantesConfirmacion"
              placeholder="Poseedor del sacerdocio"
              label="Acompañantes"
              onUpdate={updateArray}
              onDuplicate={duplicateArrayItem}
              onRemove={removeArrayItem}
            />
          </div>

          <Separator />

          <SectionTitle number="9" title="Testimonio" />
          <div className="bg-blue-50/30 p-5 rounded-xl border border-[#d1e6f9] text-[14px] text-[#323130] mb-8">
            Los nuevos conversos comparten sus testimonios, <span className="font-bold">si así lo desean</span>.
          </div>

          <Separator />

          <SectionTitle number="10" title="Himno y oración final" />
          <div className="grid grid-cols-1 gap-2">
            <InputField label="Himno" value={formData.himnoFinal} onChange={(v) => updateField('himnoFinal', v)} />
            <InputField label="Oración" value={formData.oracionFinal} onChange={(v) => updateField('oracionFinal', v)} />
          </div>

          <Separator />

          <SectionTitle number="11" title="Música de posludio" />
          <div className="bg-[#f8f9fa] p-5 rounded-2xl border border-[#edebe9] mb-8">
            {/* Texto eliminado según solicitud */}
            <div className="flex flex-col sm:flex-row gap-3">
              <CheckboxItem 
                label="Pianista u organista" 
                checked={formData.posludioPianista} 
                onChange={(v) => updateField('posludioPianista', v)} 
              />
              <CheckboxItem 
                label="Grabación" 
                checked={formData.posludioGrabacion} 
                onChange={(v) => updateField('posludioGrabacion', v)} 
              />
            </div>
          </div>
        </FormCard>

        {/* CONSIDERACIONES FINALES */}
        <div className="bg-white p-10 rounded-3xl mb-12 border border-[#edebe9] text-[#605e5c] shadow-sm">
          <h3 className="font-bold text-[15px] mb-8 flex items-center gap-3 text-[#323130]">
            <div className="w-2 h-6 bg-[#0078d4] rounded-full"></div>
            CONSIDERACIONES
          </h3>
          <div className="space-y-6 text-[13px] leading-relaxed">
            <div className="flex gap-4">
              <span className="text-[#0078d4] font-bold">1.</span>
              <p>
                Las ordenanzas y las bendiciones son sagradas; por esa razón, <strong>nadie debe tomar fotografías ni hacer grabaciones de video</strong> de ordenanzas bautismales. No obstante, cuando un familiar cercano no pueda asistir en persona por motivos excepcionales, el obispo puede autorizar que la ordenanza sea transmitida para esa persona. (véase 38.2.2).
              </p>
            </div>
            <div className="flex gap-4">
              <span className="text-[#0078d4] font-bold">2.</span>
              <p>
                A los <strong>miembros nuevos se los reconoce y se les da la bienvenida</strong> como nuevos miembros del barrio en la <strong>reunión sacramental</strong> después de su confirmación (véase 29.2.1.1).
              </p>
            </div>
            <div className="flex gap-4">
              <span className="text-[#0078d4] font-bold">3.</span>
              <p>
                Después del bautismo y de la confirmación el secretario de barrio crea la cédula de miembro. Una vez creada la cédula de miembro, <strong>el secretario prepara el Certificado de bautismo y confirmación</strong>; el obispo lo firma y lo entrega a la persona. (véase 18.8.3).
              </p>
            </div>
          </div>
        </div>

        {/* ACCIONES */}
        <div className="flex flex-col sm:flex-row justify-center items-center gap-6 no-print mb-20">
          <button 
            onClick={() => window.print()}
            className="w-full sm:w-auto flex items-center justify-center space-x-4 bg-[#0078d4] hover:bg-[#005a9e] text-white px-14 py-4 rounded-xl font-bold transition-all shadow-xl shadow-blue-200 active:scale-95 uppercase tracking-wider text-sm"
          >
            <i className="fas fa-print"></i>
            <span>IMPRIMIR PROGRAMA</span>
          </button>
          <button 
            onClick={() => confirm("¿Deseas reiniciar el formulario?") && setFormData(initialFormData)}
            className="text-[#605e5c] hover:text-red-500 text-xs font-bold uppercase tracking-widest transition-colors flex items-center gap-2"
          >
            <i className="fas fa-redo-alt"></i>
            Reiniciar Todo
          </button>
        </div>

        {/* FOOTER */}
        <footer className="text-center py-12 border-t border-[#edebe9] text-[#a19f9d] text-[11px] no-print">
          <p className="mb-2 font-bold uppercase tracking-[0.2em]">Planeación de Ordenanzas Sagradas</p>
          <p>Este formato respeta íntegramente el contenido del programa bautismal oficial.</p>
        </footer>
      </div>
    </div>
  );
};

export default App;
